package Staff;

public enum Gender {
    MALE,
    FEMALE,
    OTHER;

}
