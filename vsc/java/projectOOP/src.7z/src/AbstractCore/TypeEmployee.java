package AbstractCore;

public interface TypeEmployee {
    void position();

    void salary();
}
