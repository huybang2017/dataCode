package AbstractCore;

public interface TypeList {
    void add();

    void edit();

    void remove();

    void find();

    void display();

}