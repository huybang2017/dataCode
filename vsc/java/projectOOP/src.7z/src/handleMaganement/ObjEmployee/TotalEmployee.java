package handleMaganement.ObjEmployee;

public class TotalEmployee {
    
}
