package handleMaganement;

public class Person {
    private String name;
    private String telephoneNumber;
    private int age;
    protected String address;
    private String gender;

    public Person() {

    };

    public Person(String name, String telephoneNumber, int age, String address, String gender) {
        this.name = name;
        this.telephoneNumber = telephoneNumber;
        this.age = age;
        this.address = address;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

}
