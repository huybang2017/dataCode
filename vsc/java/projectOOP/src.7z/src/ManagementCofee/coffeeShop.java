// package ManagementCofee;

// private List<Order> orders;
//     private List<Customer> customers;
//     private List<Employee> employees;

//     public CoffeeShop() {
//         this.tables = new ArrayList<>();
//         this.menu = new Menu();
//         this.orders = new ArrayList<>();
//         this.customers = new ArrayList<>();
//         this.employees = new ArrayList<>();
//         // Khởi tạo dữ liệu cho quán cà phê (bàn, thực đơn, ...)
//     }