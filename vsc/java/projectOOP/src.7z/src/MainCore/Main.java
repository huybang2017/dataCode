package MainCore;

public class Main {
    public static void main(String[] args) {
        CoffeeShopManagement coffeeShop = new CoffeeShopManagement();
        coffeeShop.CoffeeMenu();
    }
}
