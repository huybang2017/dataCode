package OverrideCore;

import AbstractCore.TypeEmployee;
import handleMaganement.ObjEmployee.Employee;

public class SalaryManager extends Employee implements TypeEmployee {
}