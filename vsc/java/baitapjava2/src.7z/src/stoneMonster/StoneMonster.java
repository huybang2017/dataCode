package stoneMonster;

import monster.Monster;

public class StoneMonster extends Monster {
    public StoneMonster(){};
    public void attack(){
        System.out.println("StoneMonster attack!");
    }
}
