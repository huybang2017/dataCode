import managerMonster.ManagerMonster;

public class Main {
    public static void main(String[] args) {
        ManagerMonster managerMonster = new ManagerMonster();
        managerMonster.managemnet();
    }
}