package fireMonster;

import monster.Monster;

public class FireMonster extends Monster {
    public FireMonster(){};
    public void attack(){
        System.out.println("FireMonster attack!");
    }
}
