package waterMonster;

import monster.Monster;

public class WaterMonster extends Monster {
    public WaterMonster(){};
    public void attack(){
        System.out.println("WaterMonster attack!");
    }
}
