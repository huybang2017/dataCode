package managerMonster;

import fireMonster.FireMonster;
import monster.Monster;
import stoneMonster.StoneMonster;
import waterMonster.WaterMonster;

import java.util.Scanner;

public class ManagerMonster {

    private int quantityMonster;
    Monster[] monsters = new Monster[100];

    public ManagerMonster() {
    }
    Scanner scanner = new Scanner(System.in);
    public void addFireMonster() {
        FireMonster fireMonster = new FireMonster();
        System.out.println("nhập tên fire monster: ");
        String name = scanner.nextLine();
        fireMonster.setName(name);
        for (int i = 0; i < this.quantityMonster; i++) {
            if (monsters[i] == null) {
                monsters[i] = fireMonster;
                break;
            }
        }
    }

    public void addWaterMonster() {
        WaterMonster waterMonster = new WaterMonster();
        System.out.println("nhập tên water monster: ");
        String name = scanner.nextLine();
        waterMonster.setName(name);
        for (int i = 0; i < this.quantityMonster; i++) {
            if (monsters[i] == null) {
                monsters[i] = waterMonster;
                break;
            }
        }
    }

    public void addStoneMonster() {
        StoneMonster stoneMonster = new StoneMonster();
        System.out.println("nhập tên stone monster: ");
        String name = scanner.nextLine();
        stoneMonster.setName(name);
        for (int i = 0; i < this.quantityMonster; i++) {
            if (monsters[i] == null) {
                monsters[i] = stoneMonster;
                break;
            }
        }
    }

    public void searchMonster(String name) {
        for (int i = 0; i < this.quantityMonster; i++) {
            if(monsters[i].getName().toUpperCase().trim().equals(name.toUpperCase().trim())){
                monsters[i].attack();
            }
        }

    }
    public void callAttack(){
        for (int i = 0; i < this.quantityMonster; i++) {
            monsters[i].attack();
        }
    }

    public int getQuantityMonster() {
        return quantityMonster;
    }

    public void setQuantityMonster(int quantityMonster) {
        this.quantityMonster = quantityMonster;
    }

    public void managemnet(){
        boolean flag = true;
        while (flag){
            System.out.println("chọn phương thức (1.thêm quái vật,2.tất cả cùng attack,3.tìm kiếm quái vật băng tên,0.để thoát)");
            int phuongThuc = Integer.parseInt(scanner.nextLine());
            switch (phuongThuc){
                case 1:
                    System.out.println("nhập số lượng quái vật: ");
                    int quantity = Integer.parseInt(scanner.nextLine());
                    this.setQuantityMonster(quantity);
                    for (int i = 0; i < this.quantityMonster; i++) {
                        System.out.println("chọn quái vật: (1.fireMonster,2.waterMonster,3.stoneMonster");
                        int choice = Integer.parseInt(scanner.nextLine());
                        switch (choice){
                            case 1:
                                this.addFireMonster();
                                break;
                            case 2:
                                this.addWaterMonster();
                                break;
                            case 3:
                                this.addStoneMonster();
                                break;
                            default:
                                i--;
                                break;
                        }
                    }
                    break;
                case 2:
                    System.out.println("tất cả cùng attack: !!!!!!!!!!!!!!");
                    this.callAttack();
                    break;
                case 3:
                    System.out.print("nhập tên quái vật cần tìm kiếm: ");
                    String name = scanner.nextLine();
                    this.searchMonster(name);
                    break;
                case 0:
                    flag = false;
                    break;
                default:
                    break;
            }
        }
    }
}
